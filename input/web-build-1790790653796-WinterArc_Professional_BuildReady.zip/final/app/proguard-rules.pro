# Winter Arc does not require custom ProGuard/R8 rules.
