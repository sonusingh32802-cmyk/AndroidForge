# Winter Arc — Native Android personal tracker

A local-only native Android tracker for the Winter Arc routine. The project keeps the original feature set while using a conservative Android/Gradle toolchain compatible with common GitHub Actions builders.

## Included features
- Dashboard + daily Winter Arc score
- Persistent daily checklist
- School and non-school CBSE Class X study schedules
- Subject rotation and study blocks
- Weekly running + strength plan
- Strength A/B exercise checklists
- Food/protein/meal checklist
- Basic AM/PM skincare checklist
- Height/weight measurement log stored on-device
- On-device persistence
- Reality/safety notes for teen training, nutrition and growth

## Build configuration
- Android Gradle Plugin: 8.1.4
- Gradle: 8.0.x-compatible (minimum required by AGP 8.1)
- Kotlin: 1.9.24
- JDK: 17
- compileSdk / targetSdk: 34
- minSdk: 26

The project intentionally has no account, server, paid API, or network requirement.

### GitHub Actions
The included workflow installs JDK 17 and Gradle 8.0.2, installs Android SDK 34/build-tools 34.0.0, builds both debug and release APKs, and uploads them as artifacts.

### Local build
Use Android Studio with JDK 17, Android SDK 34, and Gradle 8.0.x.
