# Winter Arc — Native Android personal tracker

A small, local-only Android tracker for a Winter Arc routine.

## Current build
- Native Kotlin/Android app
- Persistent daily checklist using SharedPreferences
- Daily score
- Reset-today action
- No account, server, or paid API

## Build requirements
- JDK 17
- Android SDK 34
- Gradle 8.0
- Android Gradle Plugin 8.1.4
- Kotlin 1.9.24

The original project archive was missing the `MainActivity` source referenced by the manifest and used an Android Gradle Plugin version that is not compatible with the Gradle 8.0 fallback used by the builder. Those blockers have been corrected in this build-ready version.
