plugins {
    // Gradle 8.0 compatible Android Gradle Plugin.
    id("com.android.application") version "8.1.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
