package com.winterarc.app

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("winter_arc", Context.MODE_PRIVATE) }
    private lateinit var scoreText: TextView
    private lateinit var list: LinearLayout

    private val tasks = listOf(
        "School / classes completed",
        "Maths study block",
        "Science study block",
        "English / Hindi study block",
        "Running or strength session",
        "Protein-rich meals",
        "AM skincare",
        "PM skincare",
        "Sleep routine"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(0xFFFAFAFA.toInt())
        }

        val title = TextView(this).apply {
            text = "Winter Arc"
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF111111.toInt())
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Daily tracker • saved on this phone"
            textSize = 15f
            setTextColor(0xFF555555.toInt())
            setPadding(0, dp(4), 0, dp(14))
        }
        root.addView(subtitle, lp())

        scoreText = TextView(this).apply {
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF111111.toInt())
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(scoreText, lp())

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val reset = Button(this).apply {
            text = "Reset today"
            setOnClickListener {
                tasks.indices.forEach { prefs.edit().remove(key(it)).apply() }
                renderTasks()
            }
        }
        root.addView(reset, lp().apply { topMargin = dp(12) })

        setContentView(root)
        renderTasks()
    }

    private fun renderTasks() {
        list.removeAllViews()
        var done = 0
        tasks.forEachIndexed { index, task ->
            val checked = prefs.getBoolean(key(index), false)
            if (checked) done++
            val box = CheckBox(this).apply {
                text = task
                textSize = 16f
                isChecked = checked
                setTextColor(0xFF222222.toInt())
                setPadding(0, dp(7), 0, dp(7))
                setOnCheckedChangeListener { _, value ->
                    prefs.edit().putBoolean(key(index), value).apply()
                    updateScore()
                }
            }
            list.addView(box, lp())
        }
        scoreText.text = "Today's score: $done/${tasks.size}"
    }

    private fun updateScore() {
        val done = tasks.indices.count { prefs.getBoolean(key(it), false) }
        scoreText.text = "Today's score: $done/${tasks.size}"
    }

    private fun key(index: Int) = "task_${index}_${java.time.LocalDate.now()}"

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        gravity = Gravity.CENTER_VERTICAL
    }
}
