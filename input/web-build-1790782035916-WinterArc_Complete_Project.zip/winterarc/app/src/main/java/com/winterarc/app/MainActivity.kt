package com.winterarc.app

import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var title: TextView
    private val prefs by lazy { getSharedPreferences("winter_arc", Context.MODE_PRIVATE) }

    private val bg = Color.rgb(248,248,248)
    private val card = Color.WHITE
    private val ink = Color.rgb(25,25,25)
    private val muted = Color.rgb(105,105,105)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showApp()
    }

    private fun dayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun datedKey(key: String): String = "${dayKey()}_$key"

    private fun showApp() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 22, 20, 12)
        }
        title = tv("WINTER ARC", 22f, true)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val day = tv(today(), 12f, false).apply { setTextColor(muted) }
        header.addView(day)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 4, 16, 90)
        }

        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 10)
            setBackgroundColor(card)
        }
        listOf(
            "HOME" to ::home,
            "STUDY" to ::study,
            "BODY" to ::body,
            "FOOD" to ::food,
            "CARE" to ::care
        ).forEach { (label, action) ->
            val b = Button(this).apply {
                text = label
                textSize = 11f
                setOnClickListener { action() }
                background = null
            }
            nav.addView(b, LinearLayout.LayoutParams(0, 58, 1f))
        }
        root.addView(nav)
        setContentView(root)
        home()
    }

    private fun home() {
        content.removeAllViews()
        content.addView(card("JANUARY PROOF", "Win the day, not the mood. Track the basics every day."))
        val items = listOf(
            "Wake target" to "5:00 non-school / 6:00 school",
            "Training" to "Run + mobility; strength 3 days/week",
            "Study" to "Deep blocks first, tuition second",
            "Food" to "3 meals + 1–2 protein-rich snacks",
            "Sleep" to "Protect an 8–10 hour sleep window",
            "Care" to "Simple skincare; no over-cleansing"
        )
        val checks = items.mapIndexed { i, pair ->
            checkRow(pair.first, pair.second, "home_$i", dated = true)
        }
        content.addView(section("TODAY'S SCORE"))
        val score = TextView(this).apply {
            textSize = 28f
            setTextColor(ink)
            setPadding(8, 8, 8, 8)
        }
        fun refresh() {
            val done = (0 until items.size).count { prefs.getBoolean(datedKey("home_$it"), false) }
            score.text = "$done / ${items.size} completed"
        }
        content.addView(score)
        checks.forEach { v ->
            content.addView(v)
        }
        refresh()
        content.addView(section("REALITY CHECK"))
        content.addView(note(
            "Height: no normal exercise can guarantee extra centimetres. The useful targets are adequate sleep, enough food, healthy activity and normal growth. " +
            "Muscle: progressive resistance + enough food + recovery. Boards: consistency beats heroic 12-hour days."
        ))
    }

    private fun study() {
        content.removeAllViews()
        content.addView(card("BOARD MODE", "Use the official CBSE syllabus + sample papers. The app is your execution tracker."))
        content.addView(section("NON-SCHOOL DAY — 5:00 WAKE"))
        listOf(
            "05:00–06:15" to "Run + warm-up/cool-down + mobility",
            "06:15–06:45" to "Shower + breakfast",
            "06:45–08:45" to "Deep Study 1 — hardest subject",
            "09:00–11:00" to "Deep Study 2 — questions/numericals",
            "11:15–12:00" to "Revision / active recall",
            "12:00–13:00" to "Lunch + reset",
            "13:00–14:00" to "Rest / short nap",
            "14:00–15:30" to "Study 3 — weaker chapter",
            "15:30–16:00" to "Snack + break",
            "16:00–17:00" to "Study 4 / PYQ",
            "17:00–18:00" to "Tuition if scheduled / otherwise light review",
            "18:00–19:00" to "Dinner + recovery",
            "19:00–20:15" to "Revision + error notebook",
            "20:15–20:30" to "Plan tomorrow + skincare",
            "20:30" to "Wind down; sleep target around 21:00"
        ).forEach { addPlanRow(it.first, it.second) }

        content.addView(section("SCHOOL DAY — NO MORNING STUDY"))
        listOf(
            "06:00–13:00" to "School + commute",
            "13:00–14:00" to "Lunch",
            "14:00–14:45" to "Rest",
            "14:45–16:00" to "Study 1 — priority board work",
            "16:00–16:30" to "Snack / reset",
            "16:30–17:15" to "Workout OR revision depending on tuition",
            "17:15–19:00" to "Tuition/commute as scheduled",
            "19:00–20:00" to "Dinner + light recovery",
            "20:00–20:30" to "Active recall / next-day plan",
            "20:30+" to "Wind down; protect sleep"
        ).forEach { addPlanRow(it.first, it.second) }

        content.addView(section("SUBJECT ROTATION"))
        listOf("Mon" to "Math + Science", "Tue" to "SST + English", "Wed" to "Math + Hindi", 
            "Thu" to "Science + SST", "Fri" to "Math + English", "Sat" to "Hindi + weak areas", 
            "Sun" to "Mixed test + error notebook").forEach { addPlanRow(it.first, it.second) }

        content.addView(note("Rule: every study block ends with 5–10 minutes of recall/questions. Don't count sitting time; count solved work."))
    }

    private fun body() {
        content.removeAllViews()
        content.addView(card("BODY", "Run for fitness; resistance training for muscle. Do not turn every day into a hard training day."))
        content.addView(section("WEEKLY TRAINING"))
        listOf(
            "MON" to "Easy run + Strength A",
            "TUE" to "Easy/moderate run + mobility",
            "WED" to "Easy run + Strength B",
            "THU" to "Easy run + mobility",
            "FRI" to "Easy run + Strength A",
            "SAT" to "Light run/walk + mobility",
            "SUN" to "Recovery / walk"
        ).forEach { addPlanRow(it.first, it.second) }

        content.addView(section("STRENGTH A — 25–35 MIN"))
        listOf("Squat", "Push-up (incline if needed)", "Backpack row", "Glute bridge", "Plank")
            .forEachIndexed { i, x -> content.addView(checkRow(x, "2–3 sets; 8–15 controlled reps where applicable", "strA_$i")) }

        content.addView(section("STRENGTH B — 25–35 MIN"))
        listOf("Split squat", "Pike push-up / incline push-up", "Backpack Romanian deadlift — light", "Calf raise", "Dead bug")
            .forEachIndexed { i, x -> content.addView(checkRow(x, "2–3 sets; controlled technique", "strB_$i")) }

        content.addView(note("Teen strength training should prioritize technique, supervision and gradual progression. No max lifts, no steroid/SARM use, no ego lifting."))
    }

    private fun food() {
        content.removeAllViews()
        content.addView(card("FOOD", "Muscle gain needs enough total food and protein. Don't use a crash bulk or junk-food bulk."))
        content.addView(section("DAILY CHECKLIST"))
        listOf(
            "Breakfast" to "Carb + protein source + fruit/veg",
            "School snack" to "Roasted chana / peanuts / sattu option",
            "Lunch" to "Rice/roti + dal + soy/paneer/other protein + vegetables",
            "Evening" to "Protein-rich snack; street food not the default",
            "Dinner" to "Roti/rice + dal/soy/paneer + vegetables",
            "Hydration" to "Drink regularly; urine generally pale yellow"
        ).forEachIndexed { i, p -> content.addView(checkRow(p.first, p.second, "food_$i")) }
        content.addView(section("SIMPLE RULE"))
        content.addView(note("Aim for a protein-containing food at each main meal. If weight is not rising over several weeks despite consistent eating, increase portions and discuss it with a parent/doctor/dietitian rather than using supplements blindly."))
    }

    private fun care() {
        content.removeAllViews()
        content.addView(card("BASIC CARE", "Keep it boring and consistent. More products ≠ faster improvement."))
        content.addView(section("AM"))
        listOf(
            "Gentle cleanse or water rinse if not oily",
            "Light moisturizer if needed",
            "Broad-spectrum SPF 30+ sunscreen"
        ).forEachIndexed { i, x -> content.addView(checkRow(x, "", "am_$i")) }
        content.addView(section("PM"))
        listOf(
            "Gentle cleanser once",
            "Moisturizer",
            "No scrubbing / picking / harsh DIY acids"
        ).forEachIndexed { i, x -> content.addView(checkRow(x, "", "pm_$i")) }
        content.addView(section("TRACKER"))
        listOf("Weekly face photo in same lighting", "Weekly body-weight check under similar conditions", "Monthly height measurement under the same technique")
            .forEachIndexed { i, x -> content.addView(checkRow(x, "", "track_$i")) }
        content.addView(section("HEIGHT / WEIGHT LOG"))
        val weightInput = EditText(this).apply { hint = "Weight (kg)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val heightInput = EditText(this).apply { hint = "Height (cm)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val saveMeasure = Button(this).apply { text = "SAVE MEASUREMENT" }
        val measurement = tv("No measurement saved yet.", 14f, false).apply { setTextColor(muted) }
        fun refreshMeasurement() {
            val h = prefs.getString("height_cm", null); val w = prefs.getString("weight_kg", null)
            measurement.text = if (h != null || w != null) "Latest: ${h ?: "—"} cm • ${w ?: "—"} kg" else "No measurement saved yet."
        }
        saveMeasure.setOnClickListener {
            if (heightInput.text.isNotBlank()) prefs.edit().putString("height_cm", heightInput.text.toString()).apply()
            if (weightInput.text.isNotBlank()) prefs.edit().putString("weight_kg", weightInput.text.toString()).apply()
            refreshMeasurement()
        }
        content.addView(heightInput); content.addView(weightInput); content.addView(saveMeasure); content.addView(measurement)
        refreshMeasurement()
        content.addView(note("If a cleanser repeatedly causes burning, cracking, or clear irritation, stop using it. Acne that is persistent, painful, scarring or worsening is a reason to see a dermatologist."))
    }

    private fun card(head: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(card)
        }
        box.addView(tv(head, 18f, true))
        box.addView(note(body))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 8, 0, 12)
        box.layoutParams = lp
        return box
    }

    private fun section(s: String): TextView =
        tv(s, 14f, true).apply { setPadding(6, 18, 6, 8) }

    private fun note(s: String): TextView =
        tv(s, 14f, false).apply { setTextColor(muted); setPadding(6, 5, 6, 10) }

    private fun tv(s: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(ink)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun addPlanRow(time: String, text: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(card)
        }
        row.addView(tv(time, 12f, true), LinearLayout.LayoutParams(95, -2))
        row.addView(note(text), LinearLayout.LayoutParams(0, -2, 1f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 2, 0, 2)
        content.addView(row, lp)
    }

    private fun checkRow(head: String, sub: String, key: String, dated: Boolean = false): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 4)
        }
        val cb = CheckBox(this).apply {
            val storageKey = if (dated) datedKey(key) else key
            isChecked = prefs.getBoolean(storageKey, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(storageKey, checked).apply()
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(head, 14f, true))
        if (sub.isNotBlank()) texts.addView(note(sub))
        row.addView(cb)
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun today(): String = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date())
}
