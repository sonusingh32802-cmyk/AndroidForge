# Winter Arc — Native Android personal tracker

Phone-friendly native Android project for the Winter Arc routine.

Included base functions:
- Dashboard + daily Winter Arc score
- Persistent daily checklist
- School and non-school CBSE Class X study schedules
- Subject rotation and study blocks
- Weekly running + strength plan
- Strength A/B exercise checklists
- Food/protein/meal checklist
- Basic AM/PM skincare checklist
- Height/weight measurement log stored on-device
- On-device persistence
- Reality/safety notes for teen training, nutrition and growth

The project is intentionally local-only: no account, server or paid API is required.

To produce an installable APK, compile this Android project with Android Studio or another Android SDK build environment.
