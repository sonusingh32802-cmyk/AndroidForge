# Winter Arc — Professional Build-Ready Android Project

Native Android Winter Arc tracker, prepared for reproducible GitHub Actions builds.

## Toolchain
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin: 2.0.21
- JDK: 17
- compileSdk / targetSdk: 35
- minSdk: 26

## Critical compatibility fix
AGP 8.7.3 requires Gradle 8.9 or newer. The previous workflow forced Gradle 8.0/8.0.2, which caused the build to stop before compilation with:

`Minimum supported Gradle version is 8.9. Current version is 8.0.`

This project now installs and uses Gradle 8.9 explicitly in GitHub Actions.

## GitHub Actions
Run **Build Winter Arc APK** manually from the Actions tab, or push to `main`. The workflow builds both debug and release APKs and uploads them as the `WinterArc-APKs` artifact.

The Node.js 20 and `setup-java@v4` messages shown by the earlier run were warnings/deprecation notices, not the root cause of the Android build failure.
